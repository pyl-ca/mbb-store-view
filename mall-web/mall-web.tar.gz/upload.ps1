# PowerShell 上传脚本
Write-Host "🚀 开始上传项目文件到服务器..." -ForegroundColor Green

$SERVER = "user@39.107.74.208"
$TARGET_DIR = "/code"

# 要上传的文件和文件夹
$FilesToUpload = @(
    'src',
    'public', 
    'package.json',
    'package-lock.json',
    'vite.config.ts',
    'tsconfig.json',
    'tsconfig.app.json', 
    'tsconfig.node.json',
    'index.html',
    'Dockerfile',
    'nginx.conf',
    '.dockerignore',
    'deploy.sh',
    '.env.production'
)

Write-Host "📦 创建压缩包..." -ForegroundColor Yellow

# 检查文件是否存在并创建压缩包
$ExistingFiles = @()
foreach ($file in $FilesToUpload) {
    if (Test-Path $file) {
        $ExistingFiles += $file
    } else {
        Write-Host "⚠️  文件不存在: $file" -ForegroundColor Yellow
    }
}

# 创建压缩包
Compress-Archive -Path $ExistingFiles -DestinationPath "mall-web.zip" -Force

Write-Host "📤 上传压缩包到服务器..." -ForegroundColor Yellow

# 上传压缩包
scp mall-web.zip "$SERVER`:$TARGET_DIR/"

if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ 上传成功！" -ForegroundColor Green
    Write-Host "🔗 现在需要SSH到服务器解压并部署：" -ForegroundColor Cyan
    Write-Host "ssh $SERVER" -ForegroundColor White
    Write-Host "cd $TARGET_DIR" -ForegroundColor White
    Write-Host "unzip -o mall-web.zip -d mall-web/" -ForegroundColor White
    Write-Host "cd mall-web" -ForegroundColor White
    Write-Host "chmod +x deploy.sh" -ForegroundColor White
    Write-Host "./deploy.sh" -ForegroundColor White
} else {
    Write-Host "❌ 上传失败！" -ForegroundColor Red
}

# 清理本地压缩包
Remove-Item "mall-web.zip" -Force
Write-Host "🧹 清理完成" -ForegroundColor Green
