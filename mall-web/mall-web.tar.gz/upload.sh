#!/bin/bash

# 快速上传脚本 - 只上传必要文件
echo "🚀 开始快速上传项目文件..."

SERVER="user@39.107.74.208"
TARGET_DIR="/code/mall-web"

# 颜色输出
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}📦 创建临时打包文件...${NC}"

# 创建要上传的文件列表
cat > upload_files.txt << EOF
package.json
package-lock.json
vite.config.ts
tsconfig.json
tsconfig.app.json
tsconfig.node.json
index.html
Dockerfile
nginx.conf
.dockerignore
deploy.sh
.env.production
src/
public/
EOF

echo -e "${YELLOW}📤 上传文件到服务器...${NC}"

# 使用 rsync 上传指定文件
rsync -avz --files-from=upload_files.txt . $SERVER:$TARGET_DIR/

# 清理临时文件
rm upload_files.txt

echo -e "${GREEN}✅ 上传完成！${NC}"
echo -e "${GREEN}🔗 现在可以SSH到服务器执行部署：${NC}"
echo "ssh $SERVER"
echo "cd $TARGET_DIR"
echo "./deploy.sh"
